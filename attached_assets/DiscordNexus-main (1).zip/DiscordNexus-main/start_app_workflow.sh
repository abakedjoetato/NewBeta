#!/bin/bash
# Run both the web app and Discord bot
python3 main.py
