#!/bin/bash
# Simple script to run the Discord bot
python3 main.py