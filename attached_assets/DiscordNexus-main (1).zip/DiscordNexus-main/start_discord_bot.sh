#!/bin/bash
cd "$(dirname "$0")"
python3 clone_bot.py