#!/bin/bash
# Run the Discord bot directly
python3 run_discord_bot.py
